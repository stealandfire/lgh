package com.stealandfire.controller;

import com.stealandfire.entity.StudentVO;
import com.stealandfire.service.IStudentService;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/students")
@Slf4j
public class StudentController {
    @Autowired
    private IStudentService studentService;

    @GetMapping
    public String printRun() {
        StudentVO studentVO = new StudentVO(1101, "TOMAD", "TOMAD@163.com", 51);
        studentService.insertStudentRecord(studentVO);
        log.info("=====================Spring Boot 正在运行=====================");
        return "Spring Boot 正在运行。。。";
    }
}
