package com.stealandfire.entity;

import lombok.Data;

@Data
public class StudentVO {
    private Integer id;
    private String name;
    private String email;
    private Integer age;

    public StudentVO(Integer id, String name, String email, Integer age) {
        this.id = id;
        this.name = name;
        this.email = email;
        this.age = age;
    }
}
