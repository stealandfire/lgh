package com.stealandfire.dao;

import com.stealandfire.entity.StudentVO;
import org.apache.ibatis.annotations.Mapper;

import java.util.List;

@Mapper
public interface StudentDao {

    List<StudentVO> findStudentById(Integer id);

    Integer insertStudentRecord(StudentVO studentVO);
}
