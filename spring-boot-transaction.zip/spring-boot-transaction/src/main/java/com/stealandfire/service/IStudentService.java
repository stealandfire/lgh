package com.stealandfire.service;


import com.stealandfire.entity.StudentVO;

import java.util.List;

public interface IStudentService {

    List<StudentVO> findStudentById(Integer id);

    Integer insertStudentRecord(StudentVO studentVO);
}
